# 2026-11-06 룰 기반 탐지기

code/detector.py: 연속 두 점 확인·해제, 결측 보고, 변화량 DRIFT, 외부 미정의 후보 표시.
code/prepare.py: 원본 KG와 문서에서 조건 생성, v1·메타데이터·인용 대조.
code/run_experiment.py: 기존판·연속 2점판·DRIFT 확장판을 정답 없이 실행·봉인.
code/evaluate.py: 봉인 검사 후 정답 14건 평가.
code/test_detector.py: 의미·경계 테스트 28개.

Python 3.12 이상. 실제 검증 Python 버전은 evaluation/tests.json. 탐지기는 표준 라이브러리만, 기존판 재현은 rdflib==7.6.0 필요.

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s code -p test_detector.py -v
# 기존 출력 폴더를 덮어쓰지 말고 새 경로를 사용한다.
python reproduce.py --output ../replay_1106
# 정답 평가도 원하면 원본 annotated CSV 경로를 별도로 지정한다.
python reproduce.py --output ../replay_1106_eval --labels "원본경로/timeseries_annotated.csv"
# 연속 2점판만 실행
python code/detector.py --input inputs/observations.csv --rules rules_baseline.json --out ../two_point_new
# 변화량 DRIFT 포함
python code/detector.py --input inputs/observations.csv --rules rules_improved.json --out ../delta_new
```

미정의 후보는 --external-candidates 후보.json으로 별도 전달한다. JSON은 객체 목록이며 sensor_id/start/end/origin/evidence 필드가 필요하다. 외부 후보는 검출 이벤트·성능 점수에 자동 혼합하지 않는다. 자동 새 이상 발견 기능은 없고 전문가 확인 문구만 표시한다.

inputs/observations.csv는 원본에서 관측 일곱 필드만 추린 복사본이다. 원본 전체 데이터, API 키, 모델 가중치는 포함하지 않는다. evaluation/의 정답 파생 표를 탐지 입력으로 넣지 않는다. GraphRAG/Agent 연결은 이후 단계다. 02·03 문서는 ZIP 밖의 동봉 파일을 읽는다.

주의: 프로토콜은 코드·입력 해시를 고정한다. 코드 변경 후 재실행은 새 버전으로 준비하고 과거 결과를 덮어쓰지 않는다. 제공 reproduce.py는 바이트 동일 코드와 입력의 재현용이다. source_audit의 조건 대조는 제조 전문가 승인을 의미하지 않는다.
