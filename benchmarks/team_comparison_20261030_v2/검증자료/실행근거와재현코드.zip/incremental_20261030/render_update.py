from pathlib import Path
import json,csv,statistics,collections,re,hashlib
O=Path(__file__).resolve().parent;OLD=O.parent/'team_comparison_20261029';D=O/'deliverables';D.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def table(headers,rs):
 def cell(x):return str(x).replace('|','\\|').replace('\n','<br>')
 return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(cell,row))+' |' for row in rs])+'\n'
def jsons(p):return [read(x) for x in sorted(Path(p).glob('*.json'))]
baseitems=[x for x in read(OLD/'canonical_items.json') if x['status']=='ready' and x['task'].endswith('_qa')]
newitems=read(O/'canonical_items.json');items=baseitems+newitems;systems={'llm':'LLM 단독','vector':'VectorRAG','graph':'GraphRAG'}
baseanswers=jsons(OLD/'answers');basegrades=jsons(OLD/'grades');newanswers=jsons(O/'answers');newgrades=jsons(O/'grades');answers=baseanswers+newanswers;grades=basegrades+newgrades
complete=len(newanswers)==57 and len(newgrades)==57 and (O/'incremental_validation.json').exists()
bygrade={(x['id'],x['mode']):x for x in grades};byanswer={(x['id'],x['mode']):x for x in answers};byitem={x['original_id']:x for x in items}
oldtrans=read(OLD/'presentation_reason_translations.json')
def reason(g):return oldtrans.get(g['id']+'_'+g['mode'],g['reason'])
def group(mode,cohort='all',split='eval',task=None):
 return [x for x in grades if x['mode']==mode and (split=='all' or x['split']==split) and (cohort=='all' or x['id'].startswith('NEW-')==(cohort=='new')) and (task is None or x['task']==task)]
def metrics(gs):
 if not gs:return {'n':0,'mean':None,'strict':0,'content':None,'evidence':None,'faithfulness':None}
 return {'n':len(gs),'mean':statistics.mean(g['score'] for g in gs),'strict':sum(g['strict_correct'] for g in gs),'content':statistics.mean(sum(g['content_atoms']) for g in gs),'evidence':statistics.mean(g['evidence_score'] for g in gs),'faithfulness':statistics.mean(g['faithfulness'] for g in gs)}
def metricrow(mode,cohort='all',split='eval',task=None):
 s=metrics(group(mode,cohort,split,task));return [systems[mode],s['n'],'미완료' if s['mean'] is None else f"{s['mean']:.3f}",str(s['strict'])+'/'+str(s['n'])]
summary={m:{c:metrics(group(m,c)) for c in ['old','new','all']} for m in systems}
doc='# 01. 수정 반영 통합 벤치마크 문항표 — 2026-10-30\n\n'
doc+='NEW-12는 사용자 요청으로 제외했다. 이전 77문항의 실행 문구·답변·점수는 유지하고, 교체된 유진 문항 중 19개만 추가했다. 수정 첨부본 103문항에서 NEW-12 1개와 기존 중복 4개를 제외하면 대표 문항 98개다. 이 중 QA 96개, 별도 시스템 검증 2개다.\n\n'
doc+=table(['구분','기존 재사용','이번 추가','현재 합계'],[['QA 문항',77,19,96],['dev',11,5,16],['eval',66,14,80],['세 방식 답변',231,57,288],['별도 오류 주입 검증',2,0,2]])
doc+='\n현재 보류 문항은 없다. 과거 유진의 사건·시계열 20문항은 NEW 문항으로 교체됐고, 성호 후속 YB-19·20은 수정 첨부본에서 빠졌다. 이전 보류 21개를 현재 실험의 누락·오답으로 집계하지 않는다. NEW-12도 실행하지 않고 제외 이력을 남겼다.\n\n'
doc+='## 유지한 중복 통합\n\n'+table(['원래 ID','대표 ID','처리'],[['YB-03','YV2-Q11','생산 순서·KG 방향·인과 한계'],['YB-09','YV2-Q21','정비 조건·샘플과 시간'],['YB-15','YV2-Q16','전류 기준·실제 설치 판단 한계'],['YB-18','YV2-Q29','실제 설치 센서 모델 확정 한계']])
doc+='\n옛 YJ-04→YB-06 통합은 이전 버전의 이력이다. 현재 중복 수에 다시 넣지 않았다. 기존 77개는 당시 통합하면서 붙인 추가 요구도 포함해 실제 실행했던 문구를 그대로 유지했다. 새 문항은 같은 센서·규칙이 등장해도 단위·불확실성·증거 수준·답변 교정 등 요구 역량이 달라 유지했다. 관련 변형 문항들이 있어 문항 수를 독립 지식 수나 독립 통계 표본 수로 해석하지 않는다.\n\n'
doc+='## 기존 77문항 — 재실행 없음\n\n'+table(['ID','구분','유형','유지한 실행 질문'],[[x['original_id'],x['split'],x['category'],x['question']] for x in baseitems])
doc+='\n## 새로 실행한 19문항\n\n'+table(['ID','구분','평가 역량','질문'],[[x['original_id'],x['split'],x['category'],x['question']] for x in newitems])
system_items=[x for x in read(OLD/'canonical_items.json') if x['task']=='system_validation']
doc+='\n## 별도 시스템 검증 2문항 — 기존 동일 KG 결과 재사용\n\n'+table(['ID','검증 질문'],[[x['original_id'],x['question']] for x in system_items])
doc+='\n## 제외와 해석 기준\n\n- NEW-12: 명시적으로 제외. 현재 SOP-003에는 ST02 TMP에 대한 정비 규칙이 없어 해당 전제가 성립하지 않는다.\n- NEW-01: 485.15 K→212°C. 원래 수치를 °C 기준과 비교하는 것은 단위 오류지만, 이 사례에서 경보 등급이 반드시 뒤집힌다고 가정하지 않는다.\n- NEW-04: “소수 첫째 자리에서 반올림”은 정수로 반올림하는 뜻으로 해석했다. 양수 사사오입에서 210의 반올림 전 구간은 [209.5, 210.5)다.\n- NEW-06·10: 지속 조건·결측 처리에서 원문에 없는 누적·보간·리셋 정책을 만들어내지 않는다.\n- NEW-19: 어느 센서인지 확인하는 최소 후속 질문을 인정한다. 불필요한 전체 현장 정보 목록을 필수 답으로 요구하지 않는다.\n\n'
doc+='공통 자료는 기존 4th-yujin의 고정 KG 2,806 triple과 문서 7개·86청크다. 입력·검색 알고리즘·모델 설정을 바꾸지 않았으며 이미 공유된 문항을 이용한 개발 재시험이다. 새 비공개 독립 평가라고 표시하지 않는다.\n'
(D/'01_통합_벤치마크_문항표.md').write_text(doc,encoding='utf-8')
report='# 02. 수정 문항 반영 — 세 방식 성능·비용 비교\n\n갱신일: 2026-10-30. 사용 모델: GPT-6.1 Sol.\n\n'
report+=('**완료: 기존 231개 답변·점수 재사용 + 새 57개 실행·AI 채점 = 96문항·288개 답변.**\n\n' if complete else f"**진행 중: 새 답변 {len(newanswers)}/57개, 새 채점 {len(newgrades)}/57개. 아래 집계는 최종본이 아니다.**\n\n")
report+='NEW-12는 제외했다. 기존 답변이나 점수를 다시 생성·교체하지 않았다. 기존 10월 29일 실행과 10월 30일의 추가 실행을 합산하므로, 단일 시점의 전체 재실험과 구분한다.\n\n'
if complete:
 report+=f"현재 eval 80문항 평균은 LLM 단독 {summary['llm']['all']['mean']:.3f}, VectorRAG {summary['vector']['all']['mean']:.3f}, GraphRAG {summary['graph']['all']['mean']:.3f}/5다. 완전 정답은 VectorRAG {summary['vector']['all']['strict']}개, GraphRAG {summary['graph']['all']['strict']}개다. 평균 변화는 새 문항을 추가한 결과이며 검색 코드 개선으로 얻은 성능 상승이 아니다.\n\n"
report+='## 주 비교 — 현재 eval 80문항\n\n'+table(['방식','완료 문항','평균 /5','완전 정답'],[metricrow(m) for m in systems])
report+='\n## 기존과 추가 문항을 분리한 결과\n\n'+table(['집합','방식','문항 수','평균 /5','완전 정답'],[[label]+metricrow(m,c) for c,label in [('old','기존 eval 66'),('new','신규 eval 14')] for m in systems])
report+='\n## 유형별 eval 결과\n\n'+table(['유형','방식','문항 수','평균 /5','완전 정답'],[[name]+metricrow(m,task=task) for task,name in [('document_qa','문서·조건 추론'),('kg_qa','KG 구조 조회')] for m in systems])
report+='\n## dev 및 전체 참고값\n\n'+table(['집합','방식','문항 수','평균 /5','완전 정답'],[[name]+metricrow(m,split=split) for split,name in [('dev','dev 16'),('all','전체 96 참고')] for m in systems])
report+='\n## 유지한 실행·채점 조건\n\n'+table(['항목','조건'],[['문서·KG','동일 문서 7개·86청크, KG 2,806 triple; 원본 해시 고정'],['자료 접근','두 RAG 모두 같은 문서 행·KG 사실 카드 303개에 접근'],['LLM 단독','외부 근거 미제공, 근거 없는 프로젝트 사실 단정 금지'],['VectorRAG','기존 로컬 all-MiniLM-L6-v2 dense cosine 검색'],['GraphRAG','동일 dense + BM25 RRF + 기존 엔티티 연결·저장 간선 탐색'],['예산','각 RAG 최대 24항목·4,000토큰'],['추가 준비','기존 코퍼스 벡터 그대로 재사용; 새 질의 19개만 번역·임베딩'],['생성','같은 GPT-6.1 Sol·low reasoning·답변 지침; 각 조건 1개 완료 답변'],['채점','내용 3요소 각1점 + 근거1점 + 충실성1점'],['새 기준','새 답변 생성 전에 정답·숫자 해석·문항 범위 검토 및 봉인'],['기존 점수','출처 동등성 정정까지 끝낸 10월29일 최종 점수 그대로 재사용']])
report+='\nGraphRAG 차이에는 키워드 검색 결합도 포함되므로 순수 간선 효과로 단정하지 않는다. 생성은 공통 실행 지침이 있는 도구 미사용 세션으로 수행했으며 팀원의 API 기반 Agent v4.1 전체 앱과 같은 구현이라고 표시하지 않는다. temperature·출력 토큰 상한을 직접 제어했다고 주장하지 않는다.\n\n'
report+='LLM 단독은 문서 미제공·판단 보류 허용 대조군이다. 모델 일반 지능 시험과 구분한다. 표준 산술·단위 변환과 질문에 주어진 가정은 추론 대상이고, 문서별 기준값·실시간 기록은 제공된 근거와 구분해 판단한다. 5점은 QA 지표이며 규칙 추출 F1_content와 다르다. 충실성 0점에는 전체 0점 처리된 거부·빈 답변도 있어 환각률로 뒤집어 해석하지 않는다.\n\n'
report+='## 문항별 점수\n\n'+table(['ID','구분','출처','LLM /5','Vector /5','Graph /5','Graph−Vector'],[[x['original_id'],x['split'],'신규' if x['original_id'].startswith('NEW-') else '기존 재사용']+[f"{bygrade[(x['original_id'],m)]['score']:.2f}" if (x['original_id'],m) in bygrade else '미완료' for m in systems]+[f"{bygrade[(x['original_id'],'graph')]['score']-bygrade[(x['original_id'],'vector')]['score']:+.2f}" if all((x['original_id'],m) in bygrade for m in systems) else '미완료'] for x in items])
report+='\n## 토큰·응답 생성 시간\n\n'
cost=[]
for name,aa in [('기존 77',baseanswers),('신규 19',newanswers),('합산 96',answers)]:
 for m in systems:
  part=[x for x in aa if x['mode']==m]
  if not part:continue
  cost.append([name,systems[m],len(part),round(statistics.mean(x['context_tokens'] for x in part),1),round(statistics.mean((x['usage'] or {}).get('input_tokens',0) for x in part),1),round(statistics.mean((x['usage'] or {}).get('output_tokens',0) for x in part),1),round(statistics.median(x['seconds'] for x in part),2)])
report+=table(['집합','방식','완료 수','평균 근거 토큰','평균 입력 토큰','평균 출력 토큰','중앙 생성시간(초)'],cost)
report+='\n입력 토큰에는 공통 실행 지침이 포함된다. 검색·인덱스 준비·번역·기준 작성·AI 채점 비용은 답변 생성 표와 별도다. 날짜·서비스 부하·캐시 상태가 달라 시간 수치로 엄격한 속도 우위를 주장하지 않는다. 실제 달러 청구 비용은 확보하지 않았다. 용량 부족은 같은 모델·입력으로 제한 재시도하며 불완전 응답을 정답으로 대체하지 않는다.\n\n'
stages={'translation_':'신규 질의 번역','new_reference_':'신규 기준 답변 작성','rubric_scope_audit_':'신규 기준 범위 검토','answer_':'신규 답변 생성','new_grade_batch_':'신규 답변 채점'}
usage=[]
for prefix,label in stages.items():
 unique={}
 for p in (O/'calls').glob('*/result.json'):
  if p.parent.name.startswith(prefix):
   call=read(p);unique[call.get('actual_request_key',p.parent.name)]=call
 calls=list(unique.values());usage.append([label,len(calls),sum((x['usage'] or {}).get('input_tokens',0) for x in calls),sum((x['usage'] or {}).get('output_tokens',0) for x in calls)])
report+='이번 추가 실행의 단계별 완료 호출이다. 기준 작성·채점 비용은 실제 답변 생성 비용과 구분했다.\n\n'+table(['이번 추가 단계','완료 호출','입력 토큰 합','출력 토큰 합'],usage)+'\n'
flags=[{'id':x['id'],'mode':x['mode']} for x in answers if len(re.findall('[一-龥]',x['response']['answer']))>len(re.findall('[가-힣]',x['response']['answer']))]
report+='## 언어와 검토 한계\n\n'+table(['방식','중국어 우세 자동 검출','문항'],[[systems[m],sum(x['mode']==m for x in flags),', '.join(x['id'] for x in flags if x['mode']==m) or '없음'] for m in systems])
report+='\n모델 원문은 보존했다. 언어 표는 문자 수 기반 점검이며 완전한 언어 인증이 아니다. 5점 지표는 의미 기반 내용·근거·충실성으로 채점하고 언어 위반은 별도 표시했다.\n\n사람 교차 채점·제조 전문가 인증·독립 미노출 검증은 수행하지 않았다. 새 문항과 정답 기준은 답변 생성 전에 고정했고, 기존·신규 문항의 관련 변형 때문에 독립 표본 수나 통계적 우월성을 주장하지 않는다. 새 문항 추가로 평균이 바뀌는 것은 모델 자체가 개선됐다는 뜻이 아니다.\n'
(D/'02_세방식_성능과비용_비교.md').write_text(report,encoding='utf-8')
analysis='# 03. 수정 반영 — GraphRAG 실패 분석과 개선안\n\n갱신일: 2026-10-30. 기존 77문항은 재사용하고 신규 19문항만 추가했다. NEW-12는 제외했다.\n\n'
if complete:
 tied=sum(round(bygrade[(x['original_id'],'graph')]['score'],2)==round(bygrade[(x['original_id'],'vector')]['score'],2) for x in newitems)
 analysis+=f"새 19문항 중 {tied}문항에서 두 RAG가 동점이었다. 새 문항은 단위·조건·증거 수준·답변 교정 능력을 평가하는 데 유용하지만, 이번 실행에서 GraphRAG의 추가 이득을 보여주지는 않았다. 기존 관계·구조 조회의 차이와 구분해 해석한다.\n\n"
 ev=[x for x in items if x['split']=='eval'];wins=[]
 for x in ev:
  i=x['original_id'];g=bygrade[(i,'graph')];v=bygrade[(i,'vector')];wins.append((x,g,v,round(g['score'],2)-round(v['score'],2)))
 analysis+=table(['eval 80문항','개수'],[['Graph 점수가 높음',sum(x[3]>0 for x in wins)],['동점',sum(x[3]==0 for x in wins)],['Vector 점수가 높음',sum(x[3]<0 for x in wins)]])
 analysis+='\n## 신규 문항에서 확인한 결과\n\n'+table(['ID','역량','Vector /5','Graph /5','Graph 채점 이유'],[[x['original_id'],x['category'],round(bygrade[(x['original_id'],'vector')]['score'],2),round(bygrade[(x['original_id'],'graph')]['score'],2),reason(bygrade[(x['original_id'],'graph')])] for x in newitems])
 worst=sorted([x for x in wins if x[1]['score']<5],key=lambda x:(x[3],x[1]['score'],x[0]['original_id']))[:12]
 analysis+='\n## 현재 eval의 주요 감점 사례\n\n'+table(['ID','Vector /5','Graph /5','근거 충분(AI 판단)','이유'],[[x['original_id'],round(v['score'],2),round(g['score'],2),'예' if g['retrieval_sufficient'] else '아니요',reason(g)] for x,g,v,d in worst])
else:analysis+=f'추가 실행 진행 중: 새 답변 {len(newanswers)}/57, 채점 {len(newgrades)}/57. 최종 승패는 완료 후 확정한다.\n\n'
analysis+='\n## 새 문항을 반영한 개선 우선순위\n\n'+table(['문제 유형','대응'],[['단위·불확실성·반올림','단위 일치 확인과 범용 산술 검증. 특정 벤치마크 정답값 하드코딩 금지'],['지속시간·샘플·결측','관측 사실과 연속 유지 증거를 분리. 문서에 없는 보간·누적·리셋 정책을 생성하지 않음'],['역추론·규칙 미발동','조건→조치 방향과 조치→조건 추정을 구분. 한 규칙 미발동을 전체 안전 허가로 확대하지 않음'],['인용문·대상 일치','실제 센서·측정량·단위·표 행이 주장을 지지하는지 검사'],['모호한 질문·부분 응답','센서가 불명확하면 최소한으로 질문. 답 가능한 항목은 남기고 실시간 값은 필요한 자료와 함께 유보'],['관계·전체 집합','범용 관계 조건 조회로 전체 결과를 계산하고 필요한 필드·출처만 압축해 전달']])
analysis+='\n새 논리·단위 문항은 그래프 탐색만으로 해결되지 않을 수 있다. 검색 실패, 입력에서 근거가 잘린 경우, 근거가 있는데도 계산·판단을 틀린 경우를 나눠 개선한다. 계산 도구를 추가한다면 두 RAG에 같은 조건으로 제공하고 별도 버전으로 검증한다.\n\n'
oldanalysis=(OLD/'deliverables/03_GraphRAG_실패분석과개선안.md').read_text(encoding='utf-8');start=oldanalysis.index('## 원인을 찾는 순서')
oldsection=oldanalysis[start:].replace('실제 탐지 결과·구간·점수·시차 자료를 연결한 후 21개 보류 문항 실행','향후 사건·시계열 벤치마크를 별도로 정의하고 탐지 결과·구간·점수·시차를 연결')
analysis+='## 이전 77문항에서 검증한 개선 근거 — 재사용\n\n아래는 이전에 수행한 진단·단일 사례이며 이번 새 19문항에 개선 코드를 적용한 결과가 아니다. 본 비교의 검색 코드는 유지했고 개선 예시 점수를 96문항 평균에 섞지 않았다. 이전 사건형 문항은 현재 버전에서 교체·삭제됐으며 아래 시계열 관련 제안은 향후 별도 평가에 관한 것이다.\n\n'+oldsection
(D/'03_GraphRAG_실패분석과개선안.md').write_text(analysis,encoding='utf-8')
V=D/'검증자료';V.mkdir(exist_ok=True)
dump(V/'성능_요약.json',summary);dump(V/'문항_변경이력.json',read(O/'change_manifest.json'))
dump(V/'completion_status.json',{'complete':complete,'qa_items':96,'answers':len(answers),'grades':len(grades),'reused_answers':231,'new_answers':len(newanswers),'new_grades':len(newgrades),'dev':16,'eval':80,'excluded_NEW12':True,'system_validation_reused':2,'active_pending':0})
dump(V/'현재_통합문항.json',items);dump(V/'언어_점검.json',flags)
if (O/'incremental_validation.json').exists():dump(V/'증분실행_검증.json',read(O/'incremental_validation.json'))
with (V/'문항별_점수.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['id','mode','task','split','score','strict_correct','content_atoms','evidence_score','faithfulness','retrieval_sufficient','reason'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(grades)
if complete:
 view='# 전체 96문항의 답변·점수\n\n기존 77문항의 원문과 점수를 유지했다. 일부 채점 사유는 한국어 표시 번역이며 모델 원문은 ZIP에 보존했다. 언어 위반 답변도 번역으로 대체하지 않는다.\n\n'
 for x in items:
  i=x['original_id'];view+='## '+i+' — '+x['question']+'\n\n'
  for m in systems:
   a=byanswer[(i,m)];g=bygrade[(i,m)];view+='### '+systems[m]+f" — {g['score']:.2f}/5\n\n"+a['response']['answer']+'\n\n채점 이유: '+reason(g)+'\n\n'
 (V/'전체_답변과채점.md').write_text(view,encoding='utf-8')
dump(O/'combined/answers.json',answers);dump(O/'combined/grades.json',grades);dump(O/'combined/items.json',items)
print(json.dumps({'complete':complete,'new_answers':len(newanswers),'new_grades':len(newgrades),'combined_answers':len(answers),'combined_grades':len(grades)}))
