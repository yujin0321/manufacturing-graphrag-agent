from pathlib import Path
import json,hashlib,zipfile,csv
O=Path(__file__).resolve().parent;OLD=O.parent/'team_comparison_20261029';D=O/'deliverables';V=D/'검증자료'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
assert read(V/'completion_status.json')['complete']
assert read(O/'incremental_validation.json')['pass']
archive=V/'실행근거와재현코드.zip'
allowed=['inputs','calls','answers','grades','evaluator_only','combined']
files=[]
for folder in allowed:files += [p for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [p for p in O.iterdir() if p.is_file() and p.suffix in ['.py','.json'] and p.name!='desktop_update_manifest.json']
baseline=OLD/'deliverables/검증자료/실행근거와재현코드.zip';oldproof=read(OLD/'deliverables/검증자료/최종파일_검증.json')
assert hashlib.sha256(baseline.read_bytes()).hexdigest()==next(x['sha256'] for x in oldproof['files'] if x['file'].endswith('.zip'))
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):
  data=p.read_bytes();name='incremental_20261030/'+p.relative_to(O).as_posix();z.writestr(name,data);manifest.append({'file':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 name='baseline_20261029_실행근거.zip';z.write(baseline,name);manifest.append({'file':name,'sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'bytes':baseline.stat().st_size})
 z.writestr('읽어주세요.md','# 증분 갱신 근거\n\n기존 77문항의 231개 답변·점수는 재사용했고, NEW-12를 뺀 새 19문항만 57개 추가 실행했다. combined/에는 합산 96문항·288개 답변·점수가 있고, answers/grades/에는 새 57개만 있다. 기존 결과는 포함된 baseline ZIP에서 확인한다.\n\n기존 코퍼스 임베딩·자료 해시·검색 코드 일치를 검사했다. reuse_eligibility_checks.json, baseline_preservation.json, incremental_validation.json이 그 근거다. 기존 파일은 수정하지 않았다. 새 기준은 답변 생성 전에 봉인했고, NEW-06의 연속/누적 해석은 모델 답변을 보기 전에 원문 대조로 정리했다. NEW-12는 실행·점수 집계에서 제외했다.\n\n실행 기록에는 기존과 새 실행의 날짜 차이가 있다. 단일 시점 전체 재실험이나 미노출 독립 검증으로 표시하지 않는다. 모든 채점은 AI 평가이며 사람 검토·전문가 인증을 주장하지 않는다.\n\n새 스크립트 incremental.py는 이전 experiment.py와 원문 snapshot을 참조한다. 재실행하려면 원래처럼 두 버전 폴더를 나란히 배치하고 Python·vendor·로컬 임베딩 모델 경로를 조정해야 한다. Codex 로그인이 필요하다. 키·자격 증명·모델 가중치는 포함하지 않았으며 독립 설치 패키지는 아니다. 기존 원본은 보존하고 새로운 실행 폴더를 사용한다. NEW-12를 포함시키거나 기존 답변을 재실행하도록 바꾸지 않는다.\n')
(V/'파일_무결성_목록.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
with (V/'문항별_점수.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==288
outputs=sorted(D.glob('*.md'));assert len(outputs)==3
proof={'complete':True,'qa_items':96,'answers':288,'grades':288,'reused_answers':231,'new_answers':57,'excluded_NEW12':True,'eval':80,'dev':16,'zip_crc_ok':True,'files':[{'file':p.relative_to(D).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [*outputs,archive]]}
(V/'최종파일_검증.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'archived_incremental_files':len(files),'zip_bytes':archive.stat().st_size,'combined_answers':288}))
