"""Move only known prior deliverables to version history, then copy final update."""
from pathlib import Path
import shutil,json,hashlib
O=Path(__file__).resolve().parent;OLD=O.parent/'team_comparison_20261029';D=O/'deliverables'
target=Path('C:/Users/ysh/Desktop/대학교/동아리/비타민/프로젝트/26-2/1029').resolve();backup=(target/'이전버전_20261029').resolve()
assert target.name=='1029' and target.parent==Path('C:/Users/ysh/Desktop/대학교/동아리/비타민/프로젝트/26-2').resolve()
assert backup.parent==target
assert json.loads((D/'검증자료/completion_status.json').read_text(encoding='utf-8'))['complete']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
oldcopy=json.loads((OLD/'desktop_copy_manifest.json').read_text(encoding='utf-8'));plans=[]
for entry in oldcopy['files']:
 rel=Path(entry['file']);assert not rel.is_absolute() and '..' not in rel.parts
 src=(target/rel).resolve();dst=(backup/rel).resolve()
 assert src.is_relative_to(target) and not src.is_relative_to(backup) and dst.is_relative_to(backup)
 plans.append((src,dst,rel))
marker=backup/'보존_기록.json'
if not marker.exists():
 backup.mkdir(parents=True,exist_ok=True);preserved=[]
 for src,dst,rel in plans:
  if not src.exists():continue
  assert src.is_file()
  if dst.exists():raise RuntimeError('Existing version-history file protected: '+str(dst))
  dst.parent.mkdir(parents=True,exist_ok=True);before=sha(src)
  # Checked absolute file targets remain within the explicitly requested 1029 folder.
  src.rename(dst);assert sha(dst)==before
  preserved.append({'file':str(rel),'sha256':before})
 marker.write_text(json.dumps({'source_version':'2026-10-29','update_date':'2026-10-30','preserved_files':preserved,'only_known_prior_deliverable_files_moved':True},ensure_ascii=False,indent=2),encoding='utf-8')
checked=[]
for src in sorted(D.rglob('*')):
 if not src.is_file():continue
 dest=(target/src.relative_to(D)).resolve();assert dest.is_relative_to(target) and not dest.is_relative_to(backup)
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);assert sha(src)==sha(dest)
 checked.append({'file':str(src.relative_to(D)),'sha256':sha(dest)})
(O/'desktop_update_manifest.json').write_text(json.dumps({'target':str(target),'backup':str(backup),'files':checked},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'target':str(target),'prior_version_backup':str(backup),'verified_files':len(checked)},ensure_ascii=False))
